package utils;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class basic  {
	
	public  static HttpURLConnection httpConn;
	
	public static boolean patternMatch(String s, Pattern p)
    {
    	Matcher m = p.matcher(s);
        
        return m.matches();
        
    }
	
	
	public static int verifyLink(String urlLink) throws IOException ,java.net.UnknownHostException{
     //Sometimes we may face exception "java.net.MalformedURLException". Keep the code in try catch block to continue the broken link analysis
     
		try {
			//Use URL Class - Create object of the URL Class and pass the urlLink as parameter 
			URL link = new URL(urlLink);
			// Create a connection using URL object (i.e., link)
			 httpConn =(HttpURLConnection)link.openConnection();
			//Set the timeout for 2 seconds
			httpConn.setConnectTimeout(2000);
			//connect using connect method
			httpConn.connect();
			
			//use getResponseCode() to get the response code. 
				if(httpConn.getResponseCode()== 200) {	
					System.out.println(urlLink+" - "+httpConn.getResponseMessage());
				}
				//if(httpConn.getResponseCode()== 404) {
				else {	
				System.out.println(urlLink+" - "+httpConn.getResponseMessage() + "Broken");
				}
				
		
     	}
			//getResponseCode method returns = IOException - if an error occurred connecting to the server. 
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
		finally {
			System.out.println(httpConn.getResponseCode());
			return ( httpConn.getResponseCode());
		}
		
        }

	
	

}
