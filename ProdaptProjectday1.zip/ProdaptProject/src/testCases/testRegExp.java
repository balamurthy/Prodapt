package testCases;

import static org.junit.jupiter.api.Assertions.*;

import java.util.regex.Pattern;

import org.junit.Assert;
import org.junit.jupiter.api.Test;

import utils.basic;

class testRegExp extends basic{

	Pattern p;
	Boolean m;
	@Test
	void testRegExp() {
	
		String exampleString = "rrybpotterabcbbaab";
			p = Pattern.compile("^H.*b$");
		 m = patternMatch(exampleString,p);
		   	System.out.println(m);

		   	Assert.assertEquals(true,m);
		
		
		
	}
	
	@Test
	void testEmailFormat() {
		String emailString = "abcxyz.com";
		p= Pattern.compile("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$");
	   	 m = patternMatch(emailString,p);
	   	System.out.println(m);

	   	Assert.assertEquals(true,m);

	}

}
