package testCases;

import javaExamples.calc;
import javaExamples.sciCalc;
import junit.framework.Assert;

public class testcalc {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		calc mycalc = new calc();
		int actual,expected;	

		expected = 7;
		actual = mycalc.add(1, 5);

		Assert.assertEquals(expected,actual);

		/*
			System.out.println(mycalc.add(10, 20,5));


		sciCalc mysci = new sciCalc();

		System.out.println(mysci.sin(2));

		System.out.println("From scifi " + mysci.add(1, 4));
		 */

	}

}
