package testCases;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import javaExamples.calc;
import junit.framework.Assert;

class junitTCAdd {

	calc mycalc = new calc();
	int actual,expected;	

	@SuppressWarnings("deprecation")
	@Test
	void b1() {
		
		
		expected = 6;
		actual = mycalc.add(1, 5);

		Assert.assertEquals(expected,actual);

	}

	@Test
	void b2() {
		
		
		expected = 10;
		actual = mycalc.add(5,4);

		Assert.assertEquals(expected,actual);

	}

	
	@Test
	void a() {

		expected = 6;
		actual = mycalc.add(1, 2,3);

		Assert.assertEquals(expected,actual);

		
	}
	
	@Test
	void testDivide() {

		expected = 5;

		actual = mycalc.divide(25,0);

		Assert.assertEquals(expected,actual);

		
	}
	
	@Test
	void testNumFormatException() {

		expected=500;

		
			actual = mycalc.exceptionNumformat("abc");
		
		Assert.assertEquals(expected,actual);

		
	}
	
	

	
	
	
}
