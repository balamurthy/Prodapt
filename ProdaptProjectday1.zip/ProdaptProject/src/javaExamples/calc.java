package javaExamples;

public class calc {

	
	public static int add(int n1,int n2)
	{
		System.out.println("From parent ");
		return n1+n2;
	}

	public static int add(int n1, String string) {
		// TODO Auto-generated method stub
		return n1 + Integer.parseInt(string);
	}

	public int add(int i, int j, int k) {
		// TODO Auto-generated method stub
		return i+j+k;
	}
	
	public int divide(int i,int j)
	{
		int result;
		try {
			result =  i/j;
		}
		catch(ArithmeticException e)
		{
			result=0;
			System.out.println("Trying to " + e.getMessage() + " so returning 0");
		}
		return result;
		}
	
	public int exceptionNumformat(String s)
	{
		int result;
		try {
		return Integer.parseInt(s);
		}
		catch (Exception n)
		{
			System.out.println(n.getMessage() + " So cant add ");
			return 0;
		}
		
		
	}
}
