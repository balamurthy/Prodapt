package javaExamples;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class regExp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*
		String exampleString = "8 May 2024";
    	   	
    	Pattern p = Pattern.compile("[0-9]{2} [a-z]{3} [0-9]{4}");
    		
    	boolean m = patternMatch(exampleString,p);
		
    		System.out.println(m);
		*/
		String exampleString = "Harrybpotterabcbbaab";
   //	 Pattern p = Pattern.compile(".*potter.*");
		Pattern p = Pattern.compile("^H.*b$");
   	boolean m = patternMatch(exampleString,p);
   	System.out.println(m);
	
		
	}
	public static boolean patternMatch(String s, Pattern p)
    {
    	Matcher m = p.matcher(s);
        
        return m.matches();
        
    }
}
