package javaExamples;

public class stringExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s = "Prodapt";
		
		System.out.println(s.equalsIgnoreCase("prodapt"));
	
		StringBuilder sb = new StringBuilder("Prodapt");
		
		sb.insert(3, "a");
		System.out.println(sb);
	}

}
