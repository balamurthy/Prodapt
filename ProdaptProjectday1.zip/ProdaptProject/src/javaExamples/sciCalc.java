package javaExamples;

public class sciCalc extends calc {

	
	public double sin(double n)
	{
		return Math.sin(n);
	}
	
	public static int add(int n1,int n2)
	{
		System.out.println("From Child  ");
		return n1+n2 + 5;
	}
}
